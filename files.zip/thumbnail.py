"""
thumbnail.py — Module de génération de thumbnails YouTube pour Assirem Music PROD.

Pipeline en 3 étapes :
  1. Charger le preset visuel du tier (genre musical)
  2. Générer un fond atmosphérique via Leonardo AI (1280x720)
  3. Composer l'overlay final via PIL (titre + logo + bordure tier)

Sortie : fichier PNG 1280x720 prêt à uploader sur YouTube.

Intégration dans le pipeline existant :
    from thumbnail import build_thumbnail
    thumb_path = build_thumbnail(
        track_title="Late Night Reggae",
        duration_label="2 HOURS",
        usage="studying",
        tier="reggae",
        output_dir="./output/thumbnails/"
    )

Auteur : Assirem Music PROD — pipeline automation
"""

from __future__ import annotations

import json
import logging
import os
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import requests
from PIL import Image, ImageDraw, ImageFont, ImageFilter

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

LOGGER = logging.getLogger(__name__)
LOGGER.setLevel(logging.INFO)

# Chemins relatifs au module (à adapter dans config.json si besoin)
MODULE_DIR = Path(__file__).parent
PRESETS_PATH = MODULE_DIR / "tier_presets.json"
ASSETS_DIR = MODULE_DIR / "assets"
LOGO_PATH = ASSETS_DIR / "amp_logo.png"           # logo blanc transparent, ~200x200
FONT_REGULAR = ASSETS_DIR / "Montserrat-Bold.ttf"  # police titre principale
FONT_BOLD = ASSETS_DIR / "Montserrat-Black.ttf"    # police durée (impactante)

# Dimensions YouTube standard
THUMB_WIDTH = 1280
THUMB_HEIGHT = 720

# Leonardo API endpoints
LEONARDO_BASE_URL = "https://cloud.leonardo.ai/api/rest/v1"
LEONARDO_KEY_PATH = MODULE_DIR.parent / "credentials" / "leonardo.key"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

@dataclass
class ThumbnailSpec:
    """Spécification complète d'un thumbnail à générer."""
    track_title: str           # ex: "Late Night Reggae"
    duration_label: str        # ex: "2 HOURS" (s'affiche en gros au-dessus du titre)
    usage: str                 # ex: "studying", "focus", "sleeping" — clé du tier
    tier: str                  # ex: "reggae", "world", "afro", "latin", "maghreb"
    output_dir: Path
    custom_prompt_suffix: str = ""  # ajout libre au prompt Leonardo


def _load_presets() -> dict:
    """Charge le fichier de presets par tier."""
    with open(PRESETS_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def _load_leonardo_key() -> str:
    """Lit la clé Leonardo depuis credentials/leonardo.key."""
    if not LEONARDO_KEY_PATH.exists():
        raise FileNotFoundError(f"Clé Leonardo introuvable à {LEONARDO_KEY_PATH}")
    return LEONARDO_KEY_PATH.read_text().strip()


# ---------------------------------------------------------------------------
# Étape 1 : génération du fond via Leonardo
# ---------------------------------------------------------------------------

def generate_background(
    spec: ThumbnailSpec,
    preset: dict,
    model_id: str = "aa77f04e-3eec-4034-9c07-d0f619684628",  # Leonardo Kino XL (cinématique)
) -> Path:
    """
    Génère un fond atmosphérique 1280x720 via Leonardo AI.
    Retourne le chemin local de l'image téléchargée.
    """
    api_key = _load_leonardo_key()
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Accept": "application/json",
        "Content-Type": "application/json",
    }

    # Compose le prompt final : preset + modifier d'usage + suffixe custom
    base_prompt = preset["leonardo_prompt"]
    usage_modifier = preset.get("default_usage_modifiers", {}).get(spec.usage, "")
    full_prompt = f"{base_prompt}{usage_modifier}{spec.custom_prompt_suffix}".strip()

    LOGGER.info("Leonardo prompt → %s", full_prompt[:120] + "...")

    # 1) Lancer la génération
    payload = {
        "prompt": full_prompt,
        "negative_prompt": preset.get("leonardo_negative_prompt", ""),
        "modelId": model_id,
        "width": THUMB_WIDTH,
        "height": THUMB_HEIGHT,
        "num_images": 1,
        "guidance_scale": 7,
        "presetStyle": "CINEMATIC",
        "alchemy": True,            # qualité supérieure (consomme plus de tokens)
        "photoReal": False,
    }
    r = requests.post(f"{LEONARDO_BASE_URL}/generations", json=payload, headers=headers, timeout=30)
    r.raise_for_status()
    generation_id = r.json()["sdGenerationJob"]["generationId"]
    LOGGER.info("Leonardo job lancé : %s", generation_id)

    # 2) Polling jusqu'à complétion (max ~90s)
    image_url = None
    for attempt in range(30):
        time.sleep(3)
        poll = requests.get(
            f"{LEONARDO_BASE_URL}/generations/{generation_id}",
            headers=headers,
            timeout=15,
        )
        poll.raise_for_status()
        gen = poll.json()["generations_by_pk"]
        if gen["status"] == "COMPLETE" and gen["generated_images"]:
            image_url = gen["generated_images"][0]["url"]
            break
        if gen["status"] == "FAILED":
            raise RuntimeError(f"Leonardo a échoué : {gen}")

    if not image_url:
        raise TimeoutError("Leonardo n'a pas répondu dans les temps (90s)")

    # 3) Télécharger l'image
    img_data = requests.get(image_url, timeout=30).content
    raw_path = spec.output_dir / f"{_sanitize(spec.track_title)}_raw.png"
    raw_path.parent.mkdir(parents=True, exist_ok=True)
    raw_path.write_bytes(img_data)
    LOGGER.info("Fond téléchargé : %s", raw_path)
    return raw_path


# ---------------------------------------------------------------------------
# Étape 2 : composition de l'overlay via PIL
# ---------------------------------------------------------------------------

def compose_overlay(
    background_path: Path,
    spec: ThumbnailSpec,
    preset: dict,
) -> Path:
    """
    Compose le thumbnail final :
      - Fond Leonardo
      - Gradient noir en bas (pour lisibilité du texte)
      - Durée en gros (ex: "2 HOURS")
      - Titre de la track
      - Logo AMP en bas-droite
      - Bordure couleur du tier sur les 4 côtés
    """
    img = Image.open(background_path).convert("RGBA")
    # Force le redimensionnement (sécurité si Leonardo a dévié)
    if img.size != (THUMB_WIDTH, THUMB_HEIGHT):
        img = img.resize((THUMB_WIDTH, THUMB_HEIGHT), Image.LANCZOS)

    # --- 1) Gradient sombre en bas pour la lisibilité ---
    gradient = Image.new("RGBA", (THUMB_WIDTH, THUMB_HEIGHT), (0, 0, 0, 0))
    grad_draw = ImageDraw.Draw(gradient)
    gradient_height = 340  # zone basse où le texte vit
    for y in range(THUMB_HEIGHT - gradient_height, THUMB_HEIGHT):
        # alpha croît de 0 (haut du gradient) à 180 (bas) — non linéaire pour douceur
        ratio = (y - (THUMB_HEIGHT - gradient_height)) / gradient_height
        alpha = int(180 * (ratio ** 1.4))
        grad_draw.rectangle([(0, y), (THUMB_WIDTH, y + 1)], fill=(0, 0, 0, alpha))
    img = Image.alpha_composite(img, gradient)

    # --- 2) Texte (durée + titre) ---
    draw = ImageDraw.Draw(img)

    duration_color = tuple(preset["text_color"]) + (255,)
    title_color = tuple(preset["text_color"]) + (255,)
    shadow_color = tuple(preset["shadow_color"]) + (200,)

    # Durée — gros, en haut de la zone texte
    duration_font = _load_font(FONT_BOLD, size=120)
    duration_text = spec.duration_label.upper()
    duration_pos = _center_text(draw, duration_text, duration_font, y=THUMB_HEIGHT - 280)
    _draw_text_with_shadow(draw, duration_pos, duration_text, duration_font, duration_color, shadow_color)

    # Titre — plus petit, en dessous
    title_font = _load_font(FONT_REGULAR, size=64)
    title_text = spec.track_title
    # auto-fit si trop long
    while title_font.getlength(title_text) > THUMB_WIDTH - 200 and title_font.size > 36:
        title_font = _load_font(FONT_REGULAR, size=title_font.size - 4)
    title_pos = _center_text(draw, title_text, title_font, y=THUMB_HEIGHT - 140)
    _draw_text_with_shadow(draw, title_pos, title_text, title_font, title_color, shadow_color)

    # --- 3) Logo AMP en bas-droite ---
    if LOGO_PATH.exists():
        logo = Image.open(LOGO_PATH).convert("RGBA")
        logo_size = 110
        logo = logo.resize((logo_size, logo_size), Image.LANCZOS)
        # rendre semi-transparent (discret)
        alpha = logo.split()[3].point(lambda p: int(p * 0.85))
        logo.putalpha(alpha)
        img.paste(logo, (THUMB_WIDTH - logo_size - 36, THUMB_HEIGHT - logo_size - 36), logo)
    else:
        LOGGER.warning("Logo introuvable à %s — thumbnail généré sans logo", LOGO_PATH)

    # --- 4) Bordure du tier (4px, couleur signature) ---
    border_color = tuple(preset["border_color"]) + (preset.get("border_alpha", 230),)
    border = Image.new("RGBA", img.size, (0, 0, 0, 0))
    bd = ImageDraw.Draw(border)
    bd.rectangle([(0, 0), (THUMB_WIDTH - 1, THUMB_HEIGHT - 1)], outline=border_color, width=6)
    img = Image.alpha_composite(img, border)

    # --- 5) Sauvegarde finale ---
    final_path = spec.output_dir / f"{_sanitize(spec.track_title)}_thumb.png"
    img.convert("RGB").save(final_path, "PNG", optimize=True)
    LOGGER.info("Thumbnail final : %s", final_path)
    return final_path


# ---------------------------------------------------------------------------
# Helpers PIL
# ---------------------------------------------------------------------------

def _load_font(path: Path, size: int) -> ImageFont.FreeTypeFont:
    """Charge une police TrueType avec fallback sur la police PIL par défaut."""
    if path.exists():
        return ImageFont.truetype(str(path), size=size)
    LOGGER.warning("Police introuvable %s — fallback police par défaut (rendu dégradé)", path)
    return ImageFont.load_default(size=size)


def _center_text(draw: ImageDraw.ImageDraw, text: str, font, y: int) -> tuple[int, int]:
    """Centre horizontalement, retourne (x, y) du coin haut-gauche."""
    text_width = draw.textlength(text, font=font)
    x = (THUMB_WIDTH - text_width) // 2
    return (int(x), y)


def _draw_text_with_shadow(draw, pos, text, font, fill_color, shadow_color, shadow_offset=4):
    """Dessine texte + ombre portée pour garantir la lisibilité sur tous fonds."""
    x, y = pos
    # Ombre dans 4 directions (effet contour épais)
    for dx, dy in [(-shadow_offset, 0), (shadow_offset, 0), (0, -shadow_offset), (0, shadow_offset),
                   (-shadow_offset, -shadow_offset), (shadow_offset, shadow_offset)]:
        draw.text((x + dx, y + dy), text, font=font, fill=shadow_color)
    # Texte principal
    draw.text((x, y), text, font=font, fill=fill_color)


def _sanitize(name: str) -> str:
    """Nettoie un nom de fichier (espaces → underscores, retire caractères spéciaux)."""
    keep = "_-"
    return "".join(c if c.isalnum() or c in keep else "_" for c in name).lower()


# ---------------------------------------------------------------------------
# Orchestrateur public
# ---------------------------------------------------------------------------

def build_thumbnail(
    track_title: str,
    duration_label: str,
    usage: str,
    tier: str,
    output_dir: str | Path,
    custom_prompt_suffix: str = "",
    keep_raw: bool = False,
) -> Path:
    """
    Point d'entrée du module.

    Args:
        track_title: titre affiché sous la durée (ex: "Late Night Reggae")
        duration_label: durée en gros (ex: "2 HOURS", "1 HOUR", "30 MIN")
        usage: clé d'usage du preset (ex: "studying", "focus", "sleeping")
        tier: clé du tier dans tier_presets.json
        output_dir: dossier de sortie
        custom_prompt_suffix: ajout libre au prompt Leonardo (optionnel)
        keep_raw: si True, garde aussi l'image Leonardo brute sans overlay

    Returns:
        Chemin du thumbnail final (PNG 1280x720)
    """
    output_dir = Path(output_dir)
    presets = _load_presets()
    if tier not in presets:
        raise ValueError(f"Tier inconnu : {tier}. Disponibles : {list(presets.keys())}")
    preset = presets[tier]

    spec = ThumbnailSpec(
        track_title=track_title,
        duration_label=duration_label,
        usage=usage,
        tier=tier,
        output_dir=output_dir,
        custom_prompt_suffix=custom_prompt_suffix,
    )

    LOGGER.info("=== Build thumbnail : %s [%s/%s] ===", track_title, tier, usage)
    bg_path = generate_background(spec, preset)
    final_path = compose_overlay(bg_path, spec, preset)

    if not keep_raw:
        bg_path.unlink(missing_ok=True)

    return final_path


# ---------------------------------------------------------------------------
# CLI pour test manuel
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    import argparse

    logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")

    parser = argparse.ArgumentParser(description="Génère un thumbnail YouTube AMP")
    parser.add_argument("--title", required=True, help="Titre de la track")
    parser.add_argument("--duration", required=True, help="Label de durée (ex: '2 HOURS')")
    parser.add_argument("--usage", default="focus", help="Usage : studying / focus / sleeping / meditation / etc.")
    parser.add_argument("--tier", required=True, choices=["reggae", "world", "afro", "latin", "maghreb"])
    parser.add_argument("--output", default="./output/thumbnails/", help="Dossier de sortie")
    parser.add_argument("--keep-raw", action="store_true", help="Garde aussi l'image Leonardo brute")
    parser.add_argument("--suffix", default="", help="Suffixe libre ajouté au prompt Leonardo")
    args = parser.parse_args()

    result = build_thumbnail(
        track_title=args.title,
        duration_label=args.duration,
        usage=args.usage,
        tier=args.tier,
        output_dir=args.output,
        custom_prompt_suffix=args.suffix,
        keep_raw=args.keep_raw,
    )
    print(f"\n✓ Thumbnail prêt : {result}")
