# Module `thumbnail.py` — Assirem Music PROD

Génère automatiquement les thumbnails YouTube de chaque track via Leonardo AI + composition PIL.

---

## Installation

### 1. Copier les fichiers dans ton pipeline

```bash
cd ~/assirem-music-prod-pipeline/
cp thumbnail.py .
cp tier_presets.json .
mkdir -p assets
```

### 2. Installer les dépendances

```bash
pip install Pillow requests
```

### 3. Préparer les assets

Place ces 3 fichiers dans `~/assirem-music-prod-pipeline/assets/` :

| Fichier | Description | Où l'obtenir |
|---|---|---|
| `amp_logo.png` | Logo AMP blanc transparent ~200x200 | Ton logo existant ou nouveau |
| `Montserrat-Bold.ttf` | Police titre | https://fonts.google.com/specimen/Montserrat |
| `Montserrat-Black.ttf` | Police durée (impactante) | Idem (même famille, poids 900) |

**Note** : Montserrat est la police signature des chaînes YouTube Music premium (Chillhop, Lofi Girl en utilisent des variantes). Tu peux la remplacer par Bebas Neue (plus condensée) ou Anton (plus rétro) selon ton goût.

### 4. Vérifier la clé Leonardo

Le module lit la clé depuis `~/assirem-music-prod-pipeline/credentials/leonardo.key` (déjà en place selon ta config existante).

---

## Utilisation

### Mode CLI (test manuel)

```bash
python thumbnail.py \
  --title "Late Night Reggae" \
  --duration "2 HOURS" \
  --usage studying \
  --tier reggae \
  --output ./output/thumbnails/
```

### Mode programmatique (intégration pipeline)

```python
from thumbnail import build_thumbnail

thumb_path = build_thumbnail(
    track_title="Andean Flute Meditation",
    duration_label="1 HOUR",
    usage="meditation",
    tier="world",
    output_dir="./output/thumbnails/",
)

# thumb_path = Path('./output/thumbnails/andean_flute_meditation_thumb.png')
```

### Intégration dans le pipeline complet

Dans ton orchestrateur principal (probablement `pipeline.py` ou équivalent) :

```python
from visual import generate_animation
from video import assemble_video
from thumbnail import build_thumbnail  # nouvel import
from youtube import upload_video

def process_track(track_metadata):
    # 1. Visuel animé (existant)
    animation = generate_animation(track_metadata)

    # 2. Vidéo finale (existant)
    video = assemble_video(track_metadata, animation)

    # 3. NOUVEAU : thumbnail
    thumb = build_thumbnail(
        track_title=track_metadata["title"],
        duration_label=track_metadata["duration_label"],  # ex: "2 HOURS"
        usage=track_metadata["usage"],                     # ex: "studying"
        tier=track_metadata["tier"],                       # ex: "reggae"
        output_dir=track_metadata["output_dir"],
    )

    # 4. Upload YouTube avec thumbnail
    upload_video(video, thumbnail=thumb, metadata=track_metadata)
```

---

## Structure des métadonnées track

Adapte ton `config.json` ou ta structure de métadonnées pour inclure les champs requis :

```json
{
  "title": "Late Night Reggae",
  "duration_label": "2 HOURS",
  "usage": "studying",
  "tier": "reggae",
  "audio_file": "input/late_night_reggae.mp3"
}
```

### Tiers disponibles

| Tier | Genre cible | Bordure |
|---|---|---|
| `reggae` | Reggae, Lo-fi Reggae | Orange chaud |
| `world` | Iran, Andean, Ethiopia chill | Or |
| `afro` | Afro House, Amapiano | Violet néon |
| `latin` | Latin chill | Rose chaud |
| `maghreb` | Oud, désert (instrumental) | Teal profond |

### Usages disponibles (modifiers du prompt Leonardo)

Selon le tier, certains usages sont prédéfinis dans `tier_presets.json` :

- `studying`, `focus`, `sleeping`, `relaxing` (reggae, latin)
- `meditation`, `studying`, `focus`, `sleeping` (world, maghreb)
- `focus`, `studying`, `party`, `driving` (afro)
- `evening`, `dinner`, `relaxing`, `studying` (latin)

Si tu passes un usage inconnu, le prompt Leonardo de base est utilisé sans modifier.

---

## Personnalisation

### Modifier l'esthétique d'un tier

Édite simplement `tier_presets.json` :

```json
"reggae": {
  "leonardo_prompt": "TON NOUVEAU PROMPT ICI",
  "border_color": [232, 89, 60],     // [R, G, B] 0-255
  "text_color": [255, 245, 220],
  ...
}
```

### Ajouter un nouveau tier

Ajoute une entrée dans `tier_presets.json` avec la même structure, et utilise sa clé dans `tier="..."`.

### Tweaker la composition PIL

Dans `thumbnail.py`, fonction `compose_overlay()` :
- Taille de la durée : `_load_font(FONT_BOLD, size=120)`
- Taille du titre : `_load_font(FONT_REGULAR, size=64)`
- Épaisseur bordure : `width=6`
- Taille logo : `logo_size = 110`
- Position gradient sombre : `gradient_height = 340`

---

## Diagnostic

**Erreur "Clé Leonardo introuvable"**
→ Vérifie que `credentials/leonardo.key` existe et contient ta clé API en clair (sans guillemets).

**Erreur "Police introuvable" (warning)**
→ Le module fonctionne quand même avec la police PIL par défaut, mais le rendu est dégradé. Ajoute les .ttf dans `assets/`.

**Leonardo timeout**
→ La génération peut prendre jusqu'à 90s. Si timeout fréquent, augmente la boucle de polling dans `generate_background()` (variable `for attempt in range(30)`).

**Texte qui déborde**
→ Le module auto-shrink le titre s'il est trop long. Si le résultat est trop petit, raccourcis ton titre (≤ 30 caractères recommandé).

---

## Roadmap

- [ ] A/B testing : générer 2 candidats avec prompts différents et utiliser le multi-thumbnail YouTube natif
- [ ] Watermark animé pour les Shorts (variante 9:16)
- [ ] Auto-suggestion du tier depuis le nom du fichier MP3 (regex)
- [ ] Cache local des fonds Leonardo pour réutiliser sur les Shorts
